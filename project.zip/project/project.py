import os
from pathlib import Path
import sys
import subprocess
try:
    from Crypto.Cipher import AES, DES, DES3, PKCS1_OAEP
    from Crypto.PublicKey import RSA, ECC
    from Crypto import Random
except:
    subprocess.run(["pip", "install", "pycryptodome"])
try:
    from pyperclip import copy
except:
    subprocess.run(["pip", "install", "pyperclip"])
from Crypto.Cipher import AES, DES, DES3, PKCS1_OAEP
from Crypto.PublicKey import RSA, ECC
from Crypto import Random
from pyperclip import copy
import pathlib
import random
class col:
    BLACK = "\033[0;30m"
    RED = "\033[0;31m"
    GREEN = "\033[0;32m"
    BROWN = "\033[0;33m"
    BLUE = "\033[0;34m"
    PURPLE = "\033[0;35m"
    CYAN = "\033[0;36m"
    LIGHT_GRAY = "\033[0;37m"
    DARK_GRAY = "\033[1;30m"
    LIGHT_RED = "\033[1;31m"
    LIGHT_GREEN = "\033[1;32m"
    YELLOW = "\033[1;33m"
    LIGHT_BLUE = "\033[1;34m"
    LIGHT_PURPLE = "\033[1;35m"
    LIGHT_CYAN = "\033[1;36m"
    LIGHT_WHITE = "\033[1;37m"
    BOLD = "\033[1m"
    FAINT = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"
    BLINK = "\033[5m"
    NEGATIVE = "\033[7m"
    CROSSED = "\033[9m"
    END = "\033[0m"
    if not __import__("sys").stdout.isatty():
        for _ in dir():
            if isinstance(_, str) and _[0] != "_":
                locals()[_] = ""
    else:
        if __import__("platform").system() == "Windows":
            kernel32 = __import__("ctypes").windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            del kernel32

AES_logo = f"""{col.LIGHT_GRAY}╔════════════════════════════════════════════╦═══╦═══╗
║ {col.BOLD}Win95CryptographyPanel{col.LIGHT_GRAY}                     ║ ? ║ X ║
╠════════════════════════════════════════════╩═══╩═══╣
║{col.DARK_GRAY}              ╔══════════════════════╗              {col.LIGHT_GRAY}║
║{col.YELLOW}           ══ {col.DARK_GRAY}║{col.LIGHT_GRAY}╦ ╦ ╦══ ╦   ╦   ╦══╦ ╦{col.DARK_GRAY}║{col.YELLOW} ══           {col.LIGHT_GRAY}║
║{col.YELLOW}          ║  ╠{col.DARK_GRAY}╣{col.LIGHT_GRAY}║ ║ ║   ║   ║   ║  ║ ║{col.DARK_GRAY}╠{col.YELLOW}╣  ║          {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ╔════════════════════════════════════════╦═══╦═══╦═══╗
║{col.LIGHT_GRAY}  ║ AES Mode                               ║ _ ║ □ ║ X ║
║{col.LIGHT_GRAY}  ╠══════════════════════╦╦═══╦╦═══════════╩═══╩═══╩═══╣
║{col.LIGHT_GRAY}  ║                ╔═════╩╩═══╩╩══════╗                ║
║{col.LIGHT_GRAY}  ║{col.YELLOW}        ══      ║ {col.YELLOW} ╦╦   ╦══╗   ╦══{col.YELLOW} ║      ══        {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}╠  ╣  ║     ╣   {col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}╠══╣  ╠══╣   ╚╗ {col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}║  ║  ║        ╠{col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}  ═╗    ║  ║    ║ {col.YELLOW}╩  ╩  ╩══╝  ══╩ {col.YELLOW} ║    ║  ║    ╔═  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW} ║  ╗   ║  ║    ╚══════════════════╝    ║  ║   ╔  ║ {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW} ╚   ╗  ║  ║                            ║  ║  ╔   ╝ {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}  ╚   ╗  ╗  ╗                          ╔  ╔  ╔   ╝  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}   ╚   ╩═╬══╩╗                        ╔╩══╬═╩   ╝   {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ╚    ║   ║                        ║   ║    ╝    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╩══╣     ║                      ║     ╠══╩     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ║   ║  ╔═ ║         ╔══╗         ║ ═╗  ║   ║    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ║   ║  ╣  ║       ╔═    ═╗       ║  ╠  ║   ║    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╠══╩═╝   ║      ║        ║      ║   ╚═╩══╣     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╚   ║   ╔ ╚    ║  ╬    ╬  ║    ╝ ╗   ║   ╝     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}      ╚═╣   ╔   ╚   ║          ║   ╝   ╗   ╠═╝      {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}         ╚══╩╗   ╚ ║            ║ ╝   ╔╩══╝         {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}              ═╗  ╚╣ ╔══╦══╦══╗ ╠╝  ╔═              {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                ╚  ║ ║  ║  ║  ║ ║  ╝                {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                 ╚ ║ ║  ║  ║  ║ ║ ╝                 {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                  ╚╣ ╚  ║  ║  ╝ ╠╝                  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                   ║  ╚ ║  ║ ╝  ║                   {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                    ║  ╚╩══╩╝  ║                    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                    ║          ║                    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                     ║        ║                     {col.LIGHT_GRAY}║
╠══{col.LIGHT_GRAY}║{col.YELLOW}                      ╚═    ═╝                      {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                        ╚══╝                        {col.LIGHT_GRAY}║
╠══║                                                    ║
║  ╠════════════════════════════════════════════════════╣
║  ║                                                    ║
║  ║                   {col.YELLOW}1. Шифрование{col.LIGHT_GRAY}                    ║
║  ║                                                    ║
║  ║                  {col.YELLOW}2. Расшифрование{col.LIGHT_GRAY}                  ║
╠══║                                                    ║
║  ║                      {col.YELLOW}3. Назад{col.LIGHT_GRAY}                      ║
╚══║                                                    ║
   ╚════════════════════════════════════════════════════╝
                      {col.YELLOW}Выбирай: """
DES_logo = f"""{col.LIGHT_GRAY}╔════════════════════════════════════════════╦═══╦═══╗
║ {col.BOLD}Win95CryptographyPanel{col.LIGHT_GRAY}                     ║ ? ║ X ║
╠════════════════════════════════════════════╩═══╩═══╣
║{col.DARK_GRAY}              ╔══════════════════════╗              {col.LIGHT_GRAY}║
║{col.YELLOW}           ══ {col.DARK_GRAY}║{col.LIGHT_GRAY}╦ ╦ ╦══ ╦   ╦   ╦══╦ ╦{col.DARK_GRAY}║{col.YELLOW} ══           {col.LIGHT_GRAY}║
║{col.YELLOW}          ║  ╠{col.DARK_GRAY}╣{col.LIGHT_GRAY}║ ║ ║   ║   ║   ║  ║ ║{col.DARK_GRAY}╠{col.YELLOW}╣  ║          {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ╔════════════════════════════════════════╦═══╦═══╦═══╗
║{col.LIGHT_GRAY}  ║ DES Mode                               ║ _ ║ □ ║ X ║
║{col.LIGHT_GRAY}  ╠══════════════════════╦╦═══╦╦═══════════╩═══╩═══╩═══╣
║{col.LIGHT_GRAY}  ║                ╔═════╩╩═══╩╩══════╗                ║
║{col.LIGHT_GRAY}  ║{col.YELLOW}        ══      ║ {col.YELLOW}╦══   ╦══╗   ╦══{col.YELLOW} ║      ══        {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}║  ║  ║     ╣   {col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}║  ║  ╠══╣   ╚╗ {col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}║  ║  ║        ╠{col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}  ═╗    ║  ║    ║ {col.YELLOW}╩══   ╩══╝  ══╩ {col.YELLOW} ║    ║  ║    ╔═  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW} ║  ╗   ║  ║    ╚══════════════════╝    ║  ║   ╔  ║ {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW} ╚   ╗  ║  ║                            ║  ║  ╔   ╝ {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}  ╚   ╗  ╗  ╗                          ╔  ╔  ╔   ╝  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}   ╚   ╩═╬══╩╗                        ╔╩══╬═╩   ╝   {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ╚    ║   ║                        ║   ║    ╝    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╩══╣     ║                      ║     ╠══╩     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ║   ║  ╔═ ║         ╔══╗         ║ ═╗  ║   ║    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ║   ║  ╣  ║       ╔═    ═╗       ║  ╠  ║   ║    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╠══╩═╝   ║      ║        ║      ║   ╚═╩══╣     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╚   ║   ╔ ╚    ║  ╬    ╬  ║    ╝ ╗   ║   ╝     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}      ╚═╣   ╔   ╚   ║          ║   ╝   ╗   ╠═╝      {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}         ╚══╩╗   ╚ ║            ║ ╝   ╔╩══╝         {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}              ═╗  ╚╣ ╔══╦══╦══╗ ╠╝  ╔═              {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                ╚  ║ ║  ║  ║  ║ ║  ╝                {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                 ╚ ║ ║  ║  ║  ║ ║ ╝                 {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                  ╚╣ ╚  ║  ║  ╝ ╠╝                  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                   ║  ╚ ║  ║ ╝  ║                   {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                    ║  ╚╩══╩╝  ║                    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                    ║          ║                    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                     ║        ║                     {col.LIGHT_GRAY}║
╠══{col.LIGHT_GRAY}║{col.YELLOW}                      ╚═    ═╝                      {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                        ╚══╝                        {col.LIGHT_GRAY}║
╠══║                                                    ║
║  ╠════════════════════════════════════════════════════╣
║  ║                                                    ║
║  ║                   {col.YELLOW}1. Шифрование{col.LIGHT_GRAY}                    ║
║  ║                                                    ║
║  ║                  {col.YELLOW}2. Расшифрование{col.LIGHT_GRAY}                  ║
╠══║                                                    ║
║  ║                      {col.YELLOW}3. Назад{col.LIGHT_GRAY}                      ║
╚══║                                                    ║
   ╚════════════════════════════════════════════════════╝
                      {col.YELLOW}Выбирай: """
DES3_logo = f"""{col.LIGHT_GRAY}╔════════════════════════════════════════════╦═══╦═══╗
║ {col.BOLD}Win95CryptographyPanel{col.LIGHT_GRAY}                     ║ ? ║ X ║
╠════════════════════════════════════════════╩═══╩═══╣
║{col.DARK_GRAY}              ╔══════════════════════╗              {col.LIGHT_GRAY}║
║{col.YELLOW}           ══ {col.DARK_GRAY}║{col.LIGHT_GRAY}╦ ╦ ╦══ ╦   ╦   ╦══╦ ╦{col.DARK_GRAY}║{col.YELLOW} ══           {col.LIGHT_GRAY}║
║{col.YELLOW}          ║  ╠{col.DARK_GRAY}╣{col.LIGHT_GRAY}║ ║ ║   ║   ║   ║  ║ ║{col.DARK_GRAY}╠{col.YELLOW}╣  ║          {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ╔════════════════════════════════════════╦═══╦═══╦═══╗
║{col.LIGHT_GRAY}  ║ 3DES Mode                              ║ _ ║ □ ║ X ║
║{col.LIGHT_GRAY}  ╠══════════════════════╦╦═══╦╦═══════════╩═══╩═══╩═══╣
║{col.LIGHT_GRAY}  ║              ╔═══════╩╩═══╩╩════════╗              ║
║{col.LIGHT_GRAY}  ║{col.YELLOW}        ══    ║ {col.YELLOW}╔═╗  ╦══  ╦══╗  ╦══{col.YELLOW}║    ══        {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║   ║ {col.YELLOW}   ╣ ║  ║ ║    ╣   {col.YELLOW}║   ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║   ║ {col.YELLOW} ═╣  ║  ║ ╠══╣  ╚╗ {col.YELLOW}║   ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║   ║ {col.YELLOW}   ╣ ║  ║ ║       ╠{col.YELLOW}║   ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}  ═╗    ║  ║  ║ {col.YELLOW}╚═╝  ╩══  ╩══╝ ══╩ {col.YELLOW}║  ║  ║    ╔═  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW} ║  ╗   ║  ║  ╚══════════════════════╝  ║  ║   ╔  ║ {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW} ╚   ╗  ║  ║                            ║  ║  ╔   ╝ {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}  ╚   ╗  ╗  ╗                          ╔  ╔  ╔   ╝  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}   ╚   ╩═╬══╩╗                        ╔╩══╬═╩   ╝   {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ╚    ║   ║                        ║   ║    ╝    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╩══╣     ║                      ║     ╠══╩     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ║   ║  ╔═ ║         ╔══╗         ║ ═╗  ║   ║    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ║   ║  ╣  ║       ╔═    ═╗       ║  ╠  ║   ║    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╠══╩═╝   ║      ║        ║      ║   ╚═╩══╣     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╚   ║   ╔ ╚    ║  ╬    ╬  ║    ╝ ╗   ║   ╝     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}      ╚═╣   ╔   ╚   ║          ║   ╝   ╗   ╠═╝      {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}         ╚══╩╗   ╚ ║            ║ ╝   ╔╩══╝         {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}              ═╗  ╚╣ ╔══╦══╦══╗ ╠╝  ╔═              {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                ╚  ║ ║  ║  ║  ║ ║  ╝                {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                 ╚ ║ ║  ║  ║  ║ ║ ╝                 {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                  ╚╣ ╚  ║  ║  ╝ ╠╝                  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                   ║  ╚ ║  ║ ╝  ║                   {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                    ║  ╚╩══╩╝  ║                    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                    ║          ║                    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                     ║        ║                     {col.LIGHT_GRAY}║
╠══{col.LIGHT_GRAY}║{col.YELLOW}                      ╚═    ═╝                      {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                        ╚══╝                        {col.LIGHT_GRAY}║
╠══║                                                    ║
║  ╠════════════════════════════════════════════════════╣
║  ║                                                    ║
║  ║                   {col.YELLOW}1. Шифрование{col.LIGHT_GRAY}                    ║
║  ║                                                    ║
║  ║                  {col.YELLOW}2. Расшифрование{col.LIGHT_GRAY}                  ║
╠══║                                                    ║
║  ║                      {col.YELLOW}3. Назад{col.LIGHT_GRAY}                      ║
╚══║                                                    ║
   ╚════════════════════════════════════════════════════╝
                      {col.YELLOW}Выбирай: """
RSA_logo = f"""{col.LIGHT_GRAY}╔════════════════════════════════════════════╦═══╦═══╗
║ {col.BOLD}Win95CryptographyPanel{col.LIGHT_GRAY}                     ║ ? ║ X ║
╠════════════════════════════════════════════╩═══╩═══╣
║{col.DARK_GRAY}              ╔══════════════════════╗              {col.LIGHT_GRAY}║
║{col.YELLOW}           ══ {col.DARK_GRAY}║{col.LIGHT_GRAY}╦ ╦ ╦══ ╦   ╦   ╦══╦ ╦{col.DARK_GRAY}║{col.YELLOW} ══           {col.LIGHT_GRAY}║
║{col.YELLOW}          ║  ╠{col.DARK_GRAY}╣{col.LIGHT_GRAY}║ ║ ║   ║   ║   ║  ║ ║{col.DARK_GRAY}╠{col.YELLOW}╣  ║          {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ╔════════════════════════════════════════╦═══╦═══╦═══╗
║{col.LIGHT_GRAY}  ║ RSA Mode                               ║ _ ║ □ ║ X ║
║{col.LIGHT_GRAY}  ╠══════════════════════╦╦═══╦╦═══════════╩═══╩═══╩═══╣
║{col.LIGHT_GRAY}  ║                ╔═════╩╩═══╩╩══════╗                ║
║{col.LIGHT_GRAY}  ║{col.YELLOW}        ══      ║ {col.YELLOW}╦═╦    ╦══   ╦╦ {col.YELLOW} ║      ══        {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}║  ║  ╣     ╠  ╣{col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}╠═╣    ╚╗   ╠══╣{col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}║  ║     ╠  ║  ║{col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}  ═╗    ║  ║    ║ {col.YELLOW}╩  ╩  ══╩   ╩  ╩{col.YELLOW} ║    ║  ║    ╔═  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW} ║  ╗   ║  ║    ╚══════════════════╝    ║  ║   ╔  ║ {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW} ╚   ╗  ║  ║                            ║  ║  ╔   ╝ {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}  ╚   ╗  ╗  ╗                          ╔  ╔  ╔   ╝  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}   ╚   ╩═╬══╩╗                        ╔╩══╬═╩   ╝   {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ╚    ║   ║                        ║   ║    ╝    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╩══╣     ║                      ║     ╠══╩     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ║   ║  ╔═ ║         ╔══╗         ║ ═╗  ║   ║    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ║   ║  ╣  ║       ╔═    ═╗       ║  ╠  ║   ║    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╠══╩═╝   ║      ║        ║      ║   ╚═╩══╣     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╚   ║   ╔ ╚    ║  ╬    ╬  ║    ╝ ╗   ║   ╝     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}      ╚═╣   ╔   ╚   ║          ║   ╝   ╗   ╠═╝      {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}         ╚══╩╗   ╚ ║            ║ ╝   ╔╩══╝         {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}              ═╗  ╚╣ ╔══╦══╦══╗ ╠╝  ╔═              {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                ╚  ║ ║  ║  ║  ║ ║  ╝                {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                 ╚ ║ ║  ║  ║  ║ ║ ╝                 {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                  ╚╣ ╚  ║  ║  ╝ ╠╝                  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                   ║  ╚ ║  ║ ╝  ║                   {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                    ║  ╚╩══╩╝  ║                    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                    ║          ║                    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                     ║        ║                     {col.LIGHT_GRAY}║
╠══{col.LIGHT_GRAY}║{col.YELLOW}                      ╚═    ═╝                      {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                        ╚══╝                        {col.LIGHT_GRAY}║
╠══║                                                    ║
║  ╠════════════════════════════════════════════════════╣
║  ║                                                    ║
║  ║                   {col.YELLOW}1. Шифрование{col.LIGHT_GRAY}                    ║
║  ║                                                    ║
║  ║                  {col.YELLOW}2. Расшифрование{col.LIGHT_GRAY}                  ║
╠══║                                                    ║
║  ║                      {col.YELLOW}3. Назад{col.LIGHT_GRAY}                      ║
╚══║                                                    ║
   ╚════════════════════════════════════════════════════╝
                      {col.YELLOW}Выбирай: """
ECC_logo = f"""{col.LIGHT_GRAY}╔════════════════════════════════════════════╦═══╦═══╗
║ {col.BOLD}Win95CryptographyPanel{col.LIGHT_GRAY}                 ║ _ ║ □ ║ X ║
╠════════════════════════════════════════════╩═══╩═══╣
║{col.DARK_GRAY}              ╔══════════════════════╗              {col.LIGHT_GRAY}║
║{col.YELLOW}           ══ {col.DARK_GRAY}║{col.LIGHT_GRAY}╦ ╦ ╦══ ╦   ╦   ╦══╦ ╦{col.DARK_GRAY}║{col.YELLOW} ══           {col.LIGHT_GRAY}║
║{col.YELLOW}          ║  ╠{col.DARK_GRAY}╣{col.LIGHT_GRAY}║ ║ ║   ║   ║   ║  ║ ║{col.DARK_GRAY}╠{col.YELLOW}╣  ║          {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ╔════════════════════════════════════════╦═══╦═══╦═══╗
║{col.LIGHT_GRAY}  ║ ECC Mode                               ║ _ ║ ? ║ X ║
║{col.LIGHT_GRAY}  ╠══════════════════════╦╦═══╦╦═══════════╩═══╩═══╩═══╣
║{col.LIGHT_GRAY}  ║                ╔═════╩╩═══╩╩══════╗                ║
║{col.LIGHT_GRAY}  ║{col.YELLOW}        ══      ║ {col.YELLOW}╦══╗  ╦══╗  ╦══╗{col.YELLOW} ║      ══        {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}║     ║  ╩  ║  ╩{col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}╠══╣  ║     ║   {col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}       ║  ║     ║ {col.YELLOW}║     ║  ╦  ║  ╦{col.YELLOW} ║     ║  ║       {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}  ═╗    ║  ║    ║ {col.YELLOW}╩══╝  ╩══╝  ╩══╝{col.YELLOW} ║    ║  ║    ╔═  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW} ║  ╗   ║  ║    ╚══════════════════╝    ║  ║   ╔  ║ {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW} ╚   ╗  ║  ║                            ║  ║  ╔   ╝ {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}  ╚   ╗  ╗  ╗                          ╔  ╔  ╔   ╝  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}   ╚   ╩═╬══╩╗                        ╔╩══╬═╩   ╝   {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ╚    ║   ║                        ║   ║    ╝    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╩══╣     ║                      ║     ╠══╩     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ║   ║  ╔═ ║         ╔══╗         ║ ═╗  ║   ║    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}    ║   ║  ╣  ║       ╔═    ═╗       ║  ╠  ║   ║    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╠══╩═╝   ║      ║        ║      ║   ╚═╩══╣     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}     ╚   ║   ╔ ╚    ║  ╬    ╬  ║    ╝ ╗   ║   ╝     {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}      ╚═╣   ╔   ╚   ║          ║   ╝   ╗   ╠═╝      {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}         ╚══╩╗   ╚ ║            ║ ╝   ╔╩══╝         {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}              ═╗  ╚╣ ╔══╦══╦══╗ ╠╝  ╔═              {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                ╚  ║ ║  ║  ║  ║ ║  ╝                {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                 ╚ ║ ║  ║  ║  ║ ║ ╝                 {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                  ╚╣ ╚  ║  ║  ╝ ╠╝                  {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                   ║  ╚ ║  ║ ╝  ║                   {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                    ║  ╚╩══╩╝  ║                    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                    ║          ║                    {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                     ║        ║                     {col.LIGHT_GRAY}║
╠══{col.LIGHT_GRAY}║{col.YELLOW}                      ╚═    ═╝                      {col.LIGHT_GRAY}║
║{col.LIGHT_GRAY}  ║{col.YELLOW}                        ╚══╝                        {col.LIGHT_GRAY}║
╠══║                                                    ║
║  ╠════════════════════════════════════════════════════╣
║  ║                                                    ║
║  ║                   {col.YELLOW}1. Шифрование{col.LIGHT_GRAY}                    ║
║  ║                                                    ║
║  ║                  {col.YELLOW}2. Расшифрование{col.LIGHT_GRAY}                  ║
╠══║                                                    ║
║  ║                      {col.YELLOW}3. Назад{col.LIGHT_GRAY}                      ║
╚══║                                                    ║
   ╚════════════════════════════════════════════════════╝
                      {col.YELLOW}Выбирай: """

def hi():
    h = f"""{col.LIGHT_GRAY}╔════════════════════════════════════════╦═══╦═══╦═══╗
║ {col.BOLD}Win95CryptographyPanel{col.LIGHT_GRAY}                 ║ _ ║ □ ║ X ║
╠════════════════════════════════════════╩═══╩═══╩═══╣
║{col.DARK_GRAY}              ╔══════════════════════╗              {col.LIGHT_GRAY}║
║{col.YELLOW}           ══ {col.DARK_GRAY}║{col.LIGHT_GRAY}╦ ╦ ╦═╗ ╦   ╦   ╦══╦ ╦{col.DARK_GRAY}║{col.YELLOW} ══           {col.LIGHT_GRAY}║
║{col.YELLOW}          ║  ╠{col.DARK_GRAY}╣{col.LIGHT_GRAY}║ ║ ║   ║   ║   ║  ║ ║{col.DARK_GRAY}╠{col.YELLOW}╣  ║          {col.LIGHT_GRAY}║
║{col.YELLOW}          ║  ╠{col.DARK_GRAY}╣{col.LIGHT_GRAY}╠═╣ ╠═╣ ║   ║   ║  ║ ║{col.DARK_GRAY}╠{col.YELLOW}╣  ║          {col.LIGHT_GRAY}║
║{col.YELLOW}          ║  ╠{col.DARK_GRAY}╣{col.LIGHT_GRAY}║ ║ ║   ║ ╦ ║ ╦ ║  ║  {col.DARK_GRAY}╠{col.YELLOW}╣  ║          {col.LIGHT_GRAY}║
║{col.YELLOW}         ║  ║ {col.DARK_GRAY}║{col.LIGHT_GRAY}╩ ╩ ╩═╝ ╩═╝ ╩═╝ ╩══╩ ╩{col.DARK_GRAY}║{col.YELLOW} ║  ║         {col.LIGHT_GRAY}║
║{col.YELLOW}         ║  ║ {col.DARK_GRAY}╚═══╦╦╦══════════╦╦╦═══╝{col.YELLOW} ║  ║         {col.LIGHT_GRAY}║
║{col.YELLOW}         ║  ║    ╔╩╩╩═        ═╩╩╩╗    ║  ║         {col.LIGHT_GRAY}║
║{col.YELLOW}         ║  ║  ╔═     ║      ║     ═╗  ║  ║         {col.LIGHT_GRAY}║
║{col.YELLOW}       ╔╝    ╚═    ╔══        ══╗    ═╝    ╚╗       {col.LIGHT_GRAY}║
║{col.YELLOW}      ╔╩══       ╔═              ═╗     ════╩╗      {col.LIGHT_GRAY}║
║{col.YELLOW}     ║      ║  ╔═                  ═╗  ║      ║     {col.LIGHT_GRAY}║
║{col.YELLOW}    ╔╩═════╣  ║         ╔══╗         ║  ╠═════╩╗    {col.LIGHT_GRAY}║
║{col.YELLOW}    ║      ║  ║       ╔═    ═╗       ║  ║      ║    {col.LIGHT_GRAY}║
║{col.YELLOW}     ╠═══╦═   ║      ║        ║      ║   ═╦═══╣     {col.LIGHT_GRAY}║
║{col.YELLOW}     ║   ║   ╔ ╗    ║  ╔╗  ╔╗  ║    ╔ ╗   ║   ║     {col.LIGHT_GRAY}║
║{col.YELLOW}      ╚══   ║   ╗   ║  ╚╝  ╚╝  ║   ╔   ║   ═══      {col.LIGHT_GRAY}║
║{col.YELLOW}         ╚══╩═   ╗ ║            ║ ╔   ═╩══╝         {col.LIGHT_GRAY}║
║{col.YELLOW}              ╚╗  ═╣            ╠═  ╔╝              {col.LIGHT_GRAY}║
║{col.YELLOW}                ╗  ║ ╔══╦══╦══╗ ║  ╔                {col.LIGHT_GRAY}║
║{col.YELLOW}                 ╗ ║ ║  ║  ║  ║ ║ ╔                 {col.LIGHT_GRAY}║
║{col.YELLOW}                  ═╣ ╚  ║  ║  ╝ ╠═                  {col.LIGHT_GRAY}║
║{col.YELLOW}                   ║  ╚ ║  ║ ╝  ║                   {col.LIGHT_GRAY}║
║{col.YELLOW}                    ║  ╚╩══╩╝  ║                    {col.LIGHT_GRAY}║
║{col.YELLOW}                    ║          ║                    {col.LIGHT_GRAY}║
║{col.YELLOW}                     ║        ║                     {col.LIGHT_GRAY}║
║{col.YELLOW}                      ╚═    ═╝                      {col.LIGHT_GRAY}║
║{col.YELLOW}                        ╚══╝                        {col.LIGHT_GRAY}║
║{col.YELLOW}                                                    {col.LIGHT_GRAY}║
╠════════════════════════════════════════════════════╣
║                 {col.YELLOW}Методы шифрования                  {col.LIGHT_GRAY}║
╠════════════════════════════════════════════════════╣
║                                                    {col.LIGHT_GRAY}║
║        {col.YELLOW}1. AES        2. DES        3. 3DES         {col.LIGHT_GRAY}║
║                                                    ║
║        {col.YELLOW}     4. RSA              5. ECC             {col.LIGHT_GRAY}║
║                                                    {col.LIGHT_GRAY}║
╠════════════════════════════════════════════════════╣
║          {col.YELLOW}            6. Выход                      {col.LIGHT_GRAY}║
╚════════════════════════════════════════════════════╝
                     {col.YELLOW}Выбирай: """
    res = ""
    s = ' ' * ((os.get_terminal_size().columns - 54) // 2)
    for i in h.split("\n"):
        res += s + i + "\n"
    print(res[:-1], end="")

def clear():
    os.system(["clear", "cls"][os.name != os.sys.platform])

seq = [chr(i) for i in range(ord('a'), ord('z') + 1)]
seq.extend([chr(i) for i in range(ord('A'), ord('Z') + 1)])
seq.extend([str(i) for i in range(0, 10)])

def encrypt_file(mode, path, key=None):
    fpath = pathlib.Path(path)
    with open(path, 'r') as f:
        content = f.read()
    
    if mode == "AES":
        cipher = AES.new(key, AES.MODE_EAX)
        ciphertext, tag = cipher.encrypt_and_digest(content.encode())
        return {
            'ciphertext': ciphertext.hex(),
            'nonce': cipher.nonce.hex(),
            'tag': tag.hex()
        }
    elif mode == "DES":
        cipher = DES.new(key, DES.MODE_EAX)
        ciphertext, tag = cipher.encrypt_and_digest(content.encode())
        return {
            'ciphertext': ciphertext.hex(),
            'nonce': cipher.nonce.hex(),
            'tag': tag.hex()
        }
    elif mode == "3DES":
        cipher = DES3.new(key, DES3.MODE_EAX)
        ciphertext, tag = cipher.encrypt_and_digest(content.encode())
        return {
            'ciphertext': ciphertext.hex(),
            'nonce': cipher.nonce.hex(),
            'tag': tag.hex()
        }
    elif mode == "RSA":
        key = RSA.generate(2048)
        cipher = PKCS1_OAEP.new(key.publickey())
        ciphertext = ""
        for i in range(0, len(content), 16):
            ciphertext += str(cipher.encrypt(content[i:i+16].encode()).hex()) + "x"
        return {
            'ciphertext': ciphertext,
            'private_key': key.export_key().decode()
        }
    elif mode == "ECC":
        key = ECC.generate(curve='P-256')
        cipher = Ecies(key.public_key())
        ciphertext = cipher.encrypt(content.encode())
        return {
            'ciphertext': ciphertext.hex(),
            'private_key': key.export_key(format='PEM')
        }

def decrypt_file(mode, path, key=None, **kwargs):
    fpath = pathlib.Path(path)
    with open(path, 'r') as f:
        encrypted_data = f.read()
    
    if mode == "AES":
        cipher = AES.new(key, AES.MODE_EAX, nonce=bytes.fromhex(kwargs['nonce']))
        plaintext = cipher.decrypt_and_verify(bytes.fromhex(encrypted_data), bytes.fromhex(kwargs['tag']))
        return plaintext.decode()
    elif mode == "DES":
        cipher = DES.new(key, DES.MODE_EAX, nonce=bytes.fromhex(kwargs['nonce']))
        plaintext = cipher.decrypt_and_verify(bytes.fromhex(encrypted_data), bytes.fromhex(kwargs['tag']))
        return plaintext.decode()
    elif mode == "3DES":
        cipher = DES3.new(key, DES3.MODE_EAX, nonce=bytes.fromhex(kwargs['nonce']))
        plaintext = cipher.decrypt_and_verify(bytes.fromhex(encrypted_data), bytes.fromhex(kwargs['tag']))
        return plaintext.decode()
    elif mode == "RSA":
        rsa_key = RSA.import_key(key)
        cipher = PKCS1_OAEP.new(rsa_key)
        plaintext = b""
        for i in encrypted_data.split("x"):
            plaintext += cipher.decrypt(bytes.fromhex(i))
        return plaintext.decode()
    elif mode == "ECC":
        ecc_key = ECC.import_key(key)
        cipher = Ecies(ecc_key)
        plaintext = cipher.decrypt(bytes.fromhex(encrypted_data))
        return plaintext.decode()

while True:
    clear()
    hi()
    chc = input()
    if chc == "6":
        clear()
        os.sys.exit(0)
    elif chc == "1":
        while True:
            res = ""
            s = ' ' * ((os.get_terminal_size().columns - 54) // 2)
            for i in AES_logo.split("\n"):
                res += s + i + "\n"
            clear()
            if (chc2 := input(res[:-1])) == "1":
                key = Random.get_random_bytes(16)
                path = input("Путь к файлу: ")
                result = encrypt_file("AES", path, key)
                
                fpath = pathlib.Path(path)
                nfp = fpath.parent / f"AES_encrypted_{fpath.stem}.{input('Расширение (например, txt): ')}"
                
                with open(nfp, 'w') as f:
                    f.write(result['ciphertext'])
                
                copy(str(key.hex()) + 'x' + str(result['nonce']) + 'x' + str(result['tag']))
                print(f"Ключ (скопирован): {str(key.hex()) + 'x' + str(result['nonce']) + 'x' + str(result['tag'])}")
                print(f"Зашифрованный файл сохранен как {nfp}")
                input("Нажмите Enter для продолжения...")
                
            elif chc2 == '2':
                path = input("Путь к файлу: ")
                temp = input("Ключ: ").split('x')
                key = bytes.fromhex(temp[0])
                nonce = temp[1]
                tag = temp[2]
                
                plaintext = decrypt_file("AES", path, key, nonce=nonce, tag=tag)
                
                fpath = pathlib.Path(path)
                nfp = fpath.parent / f"AES_decrypted_{fpath.stem if 'AES_encrypted_' not in fpath.stem else fpath.stem.replace('AES_encrypted_', '', 1)}.{input('Расширение (например, txt): ')}"
                
                with open(nfp, 'w') as f:
                    f.write(plaintext)
                
                print(f"Расшифрованный файл сохранен как {nfp}")
                input("Нажмите Enter для продолжения...")
                
            elif chc2 == '3':
                break
                
    elif chc == "2":
        while True:
            res = ""
            s = ' ' * ((os.get_terminal_size().columns - 54) // 2)
            for i in DES_logo.split("\n"):
                res += s + i + "\n"
            clear()
            if (chc2 := input(res[:-1])) == "1":
                key = Random.get_random_bytes(8)
                path = input("Путь к файлу: ")
                result = encrypt_file("DES", path, key)
                
                fpath = pathlib.Path(path)
                nfp = fpath.parent / f"DES_encrypted_{fpath.stem}.{input('Расширение (например, txt): ')}"
                
                with open(nfp, 'w') as f:
                    f.write(result['ciphertext'])
                
                copy(str(key.hex()) + 'x' + str(result['nonce']) + 'x' + str(result['tag']))
                print(f"Ключ (скопирован): {str(key.hex()) + 'x' + str(result['nonce']) + 'x' + str(result['tag'])}")
                print(f"Файл сохранен как {nfp}")
                input("Нажмите Enter для продолжения...")
                
            elif chc2 == '2':
                path = input("Путь к файлу: ")
                temp = input("Ключ: ").split('x')
                key = bytes.fromhex(temp[0])
                nonce = temp[1]
                tag = temp[2]
                
                plaintext = decrypt_file("DES", path, key, nonce=nonce, tag=tag)
                
                fpath = pathlib.Path(path)
                nfp = fpath.parent / f"DES_decrypted_{fpath.stem if 'DES_encrypted_' not in fpath.stem else fpath.stem.replace('DES_encrypted_', '', 1)}.{input('Расширение (например, txt): ')}"
                
                with open(nfp, 'w') as f:
                    f.write(plaintext)
                
                print(f"Файл сохранен как {nfp}")
                input("Нажмите Enter для продолжения...")
                
            elif chc2 == '3':
                break
                
    elif chc == "3":
        while True:
            res = ""
            s = ' ' * ((os.get_terminal_size().columns - 54) // 2)
            for i in DES3_logo.split("\n"):
                res += s + i + "\n"
            clear()
            if (chc2 := input(res[:-1])) == "1":
                key = Random.get_random_bytes(24)
                path = input("Путь к файлу: ")
                result = encrypt_file("3DES", path, key)
                
                fpath = pathlib.Path(path)
                nfp = fpath.parent / f"3DES_encrypted_{fpath.stem}.{input('Расширение (например, txt): ')}"
                
                with open(nfp, 'w') as f:
                    f.write(result['ciphertext'])
                
                copy(str(key.hex()) + 'x' + str(result['nonce']) + 'x' + str(result['tag']))
                print(f"Ключ (скопирован): {str(key.hex()) + 'x' + str(result['nonce']) + 'x' + str(result['tag'])}")
                print(f"Зашифрованный файл сохранен как {nfp}")
                input("Нажмите Enter для продолжения...")
                
            elif chc2 == '2':
                path = input("Путь к файлу: ")
                temp = input("Ключ: ").split('x')
                key = bytes.fromhex(temp[0])
                nonce = temp[1]
                tag = temp[2]

                plaintext = decrypt_file("3DES", path, key, nonce=nonce, tag=tag)
                
                fpath = pathlib.Path(path)
                nfp = fpath.parent / f"3DES_decrypted_{fpath.stem if '3DES_encrypted_' not in fpath.stem else fpath.stem.replace('3DES_encrypted_', '', 1)}.{input('Расширение (например, txt): ')}"
                
                with open(nfp, 'w') as f:
                    f.write(plaintext)
                
                print(f"Расшифрованный файл сохранен как {nfp}")
                input("Нажмите Enter для продолжения...")
                
            elif chc2 == '3':
                break
                
    elif chc == "4":
        while True:
            res = ""
            s = ' ' * ((os.get_terminal_size().columns - 54) // 2)
            for i in RSA_logo.split("\n"):
                res += s + i + "\n"
            clear()
            if (chc2 := input(res[:-1])) == "1":
                
                key = RSA.generate(2048)
                private_key = key.export_key()
                public_key = key.publickey().export_key()
                
                input_path = input("Путь к файлу: ")
                output_ext = input("Расширение (например, txt): ")
                
                with open(input_path, 'rb') as f:
                    plaintext = f.read()
                
                cipher = PKCS1_OAEP.new(key.publickey())
                chunk_size = 190
                encrypted_chunks = []
                
                for i in range(0, len(plaintext), chunk_size):
                    chunk = plaintext[i:i+chunk_size]
                    encrypted_chunks.append(cipher.encrypt(chunk))
                
                fpath = pathlib.Path(input_path)
                encrypted_path = fpath.parent / f"RSA_encrypted_{fpath.stem}.{output_ext}"
                with open(encrypted_path, 'wb') as f:
                    for chunk in encrypted_chunks:
                        f.write(chunk)
                
                key_path = fpath.parent / f"RSA_private_key_{fpath.stem}.pem"
                with open(key_path, 'wb') as f:
                    f.write(private_key)
                
                print(f"Зашифрованный файл сохранен как: {encrypted_path}")
                print(f"Приватный ключ сохранен как: {key_path}")
                print("Сохраните приватный ключ в безопасном месте!")
                input("Нажмите Enter для продолжения...")
                
            elif chc2 == '2':
                encrypted_path = input("Путь к зашифрованному файлу: ")
                key_path = input("Путь к файлу с приватным ключом: ")
                output_ext = input("Расширение расшифрованного файла (например, txt): ")
                
                with open(key_path, 'rb') as f:
                    private_key = RSA.import_key(f.read())
                
                with open(encrypted_path, 'rb') as f:
                    encrypted_data = f.read()
                
                cipher = PKCS1_OAEP.new(private_key)
                chunk_size = 256
                decrypted_chunks = []
                
                for i in range(0, len(encrypted_data), chunk_size):
                    chunk = encrypted_data[i:i+chunk_size]
                    decrypted_chunks.append(cipher.decrypt(chunk))
                
                fpath = pathlib.Path(encrypted_path)
                decrypted_path = fpath.parent / f"RSA_decrypted_{fpath.stem if 'RSA_encrypted_' not in fpath.stem else fpath.stem.replace('RSA_encrypted_', '', 1)}.{output_ext}"
                with open(decrypted_path, 'wb') as f:
                    f.write(b''.join(decrypted_chunks))
                
                print(f"Расшифрованный файл сохранен как: {decrypted_path}")
                input("Нажмите Enter для продолжения...")
                
            elif chc2 == '3':
                break

    elif chc == "5":
        while True:
            res = ""
            s = ' ' * ((os.get_terminal_size().columns - 54) // 2)
            for i in ECC_logo.split("\n"):
                res += s + i + "\n"
            clear()
            if (chc2 := input(res[:-1])) == "1":
                key = ECC.generate(curve='P-256')
                private_key = key.export_key(format='PEM')
                public_key = key.public_key().export_key(format='PEM')
                
                input_path = input("Путь к файлу для шифрования: ")
                output_ext = input("Расширение зашифрованного файла (например, enc): ")
                
                with open(input_path, 'rb') as f:
                    plaintext = f.read()
                
                ephemeral_key = ECC.generate(curve='P-256')
                
                shared_key = ephemeral_key.d * key.public_key().pointQ
                
                from Crypto.Protocol.KDF import HKDF
                from Crypto.Hash import SHA256
                aes_key = HKDF(shared_key.x.to_bytes(32, 'big') + shared_key.y.to_bytes(32, 'big'), 32, None, SHA256)
                
                cipher = AES.new(aes_key, AES.MODE_GCM)
                ciphertext, tag = cipher.encrypt_and_digest(plaintext)
                
                output_data = (ephemeral_key.public_key().export_key(format='DER') + cipher.nonce + tag + ciphertext)
                
                fpath = pathlib.Path(input_path)
                encrypted_path = fpath.parent / f"ECC_encrypted_{fpath.stem}.{output_ext}"
                with open(encrypted_path, 'wb') as f:
                    f.write(output_data)
                
                key_path = fpath.parent / f"ECC_private_key_{fpath.stem}.pem"
                with open(key_path, 'w') as f:
                    f.write(private_key)
                
                print(f"Зашифрованный файл сохранен как: {encrypted_path}")
                print(f"Приватный ключ сохранен как: {key_path}")
                input("Нажмите Enter для продолжения...")
                
            elif chc2 == '2':
                encrypted_path = input("Путь к зашифрованному файлу: ")
                key_path = input("Путь к файлу с приватным ключом: ")
                output_ext = input("Расширение расшифрованного файла (например, txt): ")
                
                with open(key_path, 'r') as f:
                    private_key = ECC.import_key(f.read())
                
                with open(encrypted_path, 'rb') as f:
                    encrypted_data = f.read()
                
                ephemeral_pubkey = ECC.import_key(encrypted_data[:91])
                
                nonce = encrypted_data[91:107]
                tag = encrypted_data[107:123]
                ciphertext = encrypted_data[123:]
                
                shared_key = private_key.d * ephemeral_pubkey.pointQ
                
                from Crypto.Protocol.KDF import HKDF
                from Crypto.Hash import SHA256
                aes_key = HKDF(shared_key.x.to_bytes(32, 'big') + shared_key.y.to_bytes(32, 'big'), 32, None, SHA256)
                
                cipher = AES.new(aes_key, AES.MODE_GCM, nonce=nonce)
                plaintext = cipher.decrypt_and_verify(ciphertext, tag)
                
                fpath = pathlib.Path(encrypted_path)
                decrypted_path = fpath.parent / f"ECC_decrypted_{fpath.stem if 'ECC_encrypted_' not in fpath.stem else fpath.stem.replace('ECC_encrypted_', '', 1)}.{output_ext}"
                with open(decrypted_path, 'wb') as f:
                    f.write(plaintext)
                
                print(f"Расшифрованный файл сохранен как: {decrypted_path}")
                input("Нажмите Enter для продолжения...")
                
            elif chc2 == '3':
                break
print(col.END)
if os.name == 'nt':
    uninstall_font(installed_path)